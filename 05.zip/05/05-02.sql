SELECT city
FROM cities
WHERE country = 'New Zealand';

