SELECT city
FROM cities;
